Place your images here with these exact filenames so the site displays them:
- kalam1.jpg
- kalam2.jpg
- kalam3.jpg
